package com.tiagohs.base_android_app.presenter.configs

import com.tiagohs.base_android_app.ui.configs.IView

interface IPresenter<V : IView> {

    fun onBindView(view: V)
    fun onUnbindView()
}