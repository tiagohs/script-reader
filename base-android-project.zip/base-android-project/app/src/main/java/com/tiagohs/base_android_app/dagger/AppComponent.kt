package com.tiagohs.base_android_app.dagger

import com.tiagohs.base_android_app.dagger.modules.AppModule
import com.tiagohs.base_android_app.dagger.modules.PresenterModule
import com.tiagohs.base_android_app.ui.activities.HomeActivity
import dagger.Component
import javax.inject.Singleton

@Component(modules = arrayOf(
    AppModule::class,
    PresenterModule::class
))
@Singleton
interface AppComponent {

    fun inject(homeActivity: HomeActivity)
}