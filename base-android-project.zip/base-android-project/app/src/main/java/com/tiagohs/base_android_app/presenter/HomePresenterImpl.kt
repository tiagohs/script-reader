package com.tiagohs.base_android_app.presenter

import com.tiagohs.base_android_app.presenter.configs.BasePresenter
import com.tiagohs.base_android_app.ui.HomeView

class HomePresenterImpl:
    BasePresenter<HomeView>(),
    HomePresenter {

}