package com.tiagohs.base_android_app.dagger.modules

import com.tiagohs.base_android_app.presenter.HomePresenter
import com.tiagohs.base_android_app.presenter.HomePresenterImpl
import dagger.Module
import dagger.Provides

@Module
class PresenterModule {

    @Provides
    fun providerHomePresenter(): HomePresenter = HomePresenterImpl()
}