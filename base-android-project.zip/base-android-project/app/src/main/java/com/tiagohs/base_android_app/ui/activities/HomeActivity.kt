package com.tiagohs.base_android_app.ui.activities

import android.os.Bundle
import com.tiagohs.base_android_app.R
import com.tiagohs.base_android_app.presenter.HomePresenter
import com.tiagohs.base_android_app.ui.HomeView
import com.tiagohs.base_android_app.ui.configs.BaseActivity
import javax.inject.Inject

class HomeActivity :
    BaseActivity(),
    HomeView {

    override fun onGetLayoutViewId(): Int = R.layout.activity_home
    override fun onGetMenuLayoutId(): Int = 0

    @Inject
    lateinit var homePresenter: HomePresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        getApplicationComponent()?.inject(this)

        homePresenter.onBindView(this)
    }
}
