package com.tiagohs.base_android_app.ui.configs

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.support.customtabs.CustomTabsIntent
import android.support.design.widget.Snackbar
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.tiagohs.base_android_app.dagger.AppComponent

abstract class BaseFragment: Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(getViewID(), container, false)
        return view
    }

    protected fun startFragment(fragmentID: Int, fragment: Fragment) {
        val fm = childFragmentManager
        val f = fm.findFragmentById(fragmentID)

        if (null == f) {
            fm.beginTransaction()
                    .add(fragmentID, fragment)
                    .commitAllowingStateLoss()
        } else {
            fm.beginTransaction()
                    .replace(fragmentID, fragment)
                    .commitAllowingStateLoss()
        }
    }

    protected fun getApplicationComponent(): AppComponent? {
        val activity = activity ?: return null
        return (activity as BaseActivity).getApplicationComponent()
    }

    fun openUrl(url: String?) {
        val activity = activity ?: return

        return (activity as BaseActivity).openUrl(url)
    }

    fun isInternetConnected(): Boolean {
        val activity = activity ?: return false

        return (activity as BaseActivity).isInternetConnected()
    }

    abstract fun getViewID(): Int

    open fun onError(ex: Throwable?, message: Int) {
        val activity = activity ?: return

        return (activity as BaseActivity).onError(ex, message)
    }

    /*fun getConfiguratedAd(adView: AdView) {
        val activity = activity ?: return

        return (activity as BaseActivity).getConfiguratedAd(adView)
    }*/

    abstract fun onErrorAction()
}