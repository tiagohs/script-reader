package com.tiagohs.base_android_app.presenter

import com.tiagohs.base_android_app.presenter.configs.IPresenter
import com.tiagohs.base_android_app.ui.HomeView

interface HomePresenter: IPresenter<HomeView> {

}