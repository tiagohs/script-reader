package com.tiagohs.base_android_app.ui

import com.tiagohs.base_android_app.ui.configs.IView

interface HomeView: IView {
}